// Sample Remix homepage with recipe list
